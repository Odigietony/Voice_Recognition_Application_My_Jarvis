﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.IO;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        SpeechRecognitionEngine speechRecog = new SpeechRecognitionEngine();
        SpeechSynthesizer jarvis = new SpeechSynthesizer();
        public Form1()
        {
            InitializeComponent();
            speechRecog.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(SpeechRecog_speechRecognise);
            LoadGrammer();
            speechRecog.SetInputToDefaultAudioDevice();
            speechRecog.RecognizeAsync(RecognizeMode.Multiple);
        }

         
        private void LoadGrammer()
        {
            Choices texts = new Choices();
            string[] lines = File.ReadAllLines(Environment.CurrentDirectory + "\\command.txt");
            texts.Add(lines);
            Grammar worldList = new Grammar(new GrammarBuilder(texts));
            speechRecog.LoadGrammar(worldList);
        }

        private void SpeechRecog_speechRecognise(object sender, SpeechRecognizedEventArgs e)
        {
            myTextbox.Text = e.Result.Text;
            string speech = e.Result.Text;
            if (speech == "hello" || speech == "Hi" || speech == "What's up" || speech == "wassup")
            {
                jarvis.Speak("Hi, good day SIR");

            }

            if (speech == "how are you jarvis")
            {
                jarvis.Speak("I'm good sir, considering I'm a machine, how about you sir?");
            }
            if (speech == "I'm Fine thank You")
            {
                jarvis.Speak("That's Excellent sir");
            }
            if (speech == "jarvis, open google")
            {
                jarvis.Speak("Right away sir, loading google");
                System.Diagnostics.Process.Start("http://www.google.com/");
            }
            if (speech== "open notepad")
            {
                jarvis.Speak("Loading Notepad");
                System.Diagnostics.Process.Start("C:\\Users\\odigietony\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Accessories\\Notepad");
            }

            if (speech == "Thank for your services jarvis")
            {
                jarvis.Speak("it has been my pleasure sir, have an awesome day.");
                Close();
            }

            if (speech == "open windows media player")
            {
                jarvis.Speak("opening windows media player, loading");
                System.Diagnostics.Process.Start("C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Accessories\\Windows Media Player");
            }
        }
    }
}
